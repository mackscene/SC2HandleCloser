﻿using Microsoft.VisualBasic.FileIO;
using CliWrap;
using System.Text;
using System.Text.Json;

Config config = JsonSerializer.Deserialize<Config>(File.ReadAllText("config.json"))!;

try
{
    MainLoop();
}
catch(Exception e)
{
    WriteLine($"Unhandled exception: {e}", ConsoleColor.Red);
}

WriteLine("Press any key to exit...");
Console.ReadKey();

return;

void MainLoop()
{
    foreach (var handleName in config.Handles)
    {
        WriteLine($"{handleName}");

        if (!TryFindHandle(handleName, out HandleEntry handle))
        {
            WriteLine("NOT FOUND\n", ConsoleColor.Red);
            continue;
        }

        WriteLine("FOUND", ConsoleColor.Green);

        if (!CloseHandle(handle))
        {
            WriteLine("FAILED TO CLOSE\n", ConsoleColor.Red);
            continue;
        }

        WriteLine("CLOSED\n", ConsoleColor.Green);
    }
}

bool TryFindHandle(string name, out HandleEntry handle)
{
    HandleEntry[] handles = GetHandles(name);
    handle = handles.SingleOrDefault(h => h.Name == name)!;

    return handle != null;
}

void WriteLine(string message, ConsoleColor color = ConsoleColor.Gray)
{
    var oldColor = Console.ForegroundColor;
    Console.ForegroundColor = color;
    Console.WriteLine(message);
    Console.ForegroundColor = oldColor;
}

HandleEntry[] GetHandles(string handleName)
{
    StringBuilder stdOutBuilder = new();
    StringBuilder stdErrBuilder = new();

    var result = Cli.Wrap("handle.exe")
        .WithArguments(["-av", "-p", config.AppName, $"""{handleName}""", "-v"])
        .WithStandardOutputPipe(PipeTarget.ToStringBuilder(stdOutBuilder))
        .WithStandardErrorPipe(PipeTarget.ToStringBuilder(stdErrBuilder))
        .ExecuteAsync().GetAwaiter().GetResult();

    if (result.ExitCode != 0)
    {
        WriteLine(stdErrBuilder.ToString(), ConsoleColor.DarkRed);
        throw new Exception($"handle.exe exited with code {result.ExitCode}");
    }

    string[] stdOutLines = stdOutBuilder.ToString()
        .Split(Environment.NewLine)
        .Skip(5)
        .Where(line => !string.IsNullOrWhiteSpace(line))
        .ToArray();

    string stdOut = string.Join(",", stdOutLines);

    using Stream stream = ToStream(stdOut);

    using TextFieldParser parser = new TextFieldParser(stream)
    {
        TrimWhiteSpace = true,
        TextFieldType = FieldType.Delimited,
        Delimiters = [","]
    };

    string[] fields = parser.ReadFields()!;

    if (fields is ["No matching handles found."])
    {
        return [];
    }

    if (fields.Length % 5 != 0)
    {
        throw new InvalidOperationException("Unexpected data.");
    }

    return ExtractHandleNames(fields).ToArray();

    IEnumerable<HandleEntry> ExtractHandleNames(string[] csvOutput)
    {
        IEnumerator<string> enumerator = csvOutput.Cast<string>().GetEnumerator();

        // Skip headers.
        enumerator.MoveNext();
        enumerator.MoveNext();
        enumerator.MoveNext();
        enumerator.MoveNext();
        enumerator.MoveNext();

        // Parse entry by entry. Last field is the name.
        while(enumerator.MoveNext())
        {
            string process = enumerator.Current;

            enumerator.MoveNext();
            string pid = enumerator.Current;

            enumerator.MoveNext();
            string type = enumerator.Current;

            enumerator.MoveNext();
            string handle = enumerator.Current;

            enumerator.MoveNext();
            string name = enumerator.Current;

            yield return new HandleEntry(process, pid, type, handle, name);
        }
    }
}

bool CloseHandle(HandleEntry handle)
{
    StringBuilder stdOutBuilder = new StringBuilder();

    var process = Cli.Wrap("handle.exe")
        .WithArguments(["-c", handle.Handle, "-p", handle.PID, "-y"])
        .WithStandardOutputPipe(PipeTarget.ToStringBuilder(stdOutBuilder))
        .ExecuteAsync().GetAwaiter().GetResult();

    WriteLine(stdOutBuilder.ToString(), ConsoleColor.Magenta);

    return process.ExitCode == 0;
}

static Stream ToStream(string str)
{
    MemoryStream stream = new MemoryStream();
    StreamWriter writer = new StreamWriter(stream);
    writer.Write(str);
    writer.Flush();
    stream.Position = 0;
    return stream;
}

record HandleEntry(string Process, string PID, string Type, string Handle, string Name);

class Config
{
    public string AppName { get; set; }
    public string[] Handles { get; set; }
}